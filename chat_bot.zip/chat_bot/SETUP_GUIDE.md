Requirements you need to install
 Python 3.8+  
 Ollama 

Setup Steps

1. Install Ollama From Browser
2. Pull a model:  
    `ollama pull qwen2.5:3b`  
    (alternatives: `gemma:2b`, `phi3`, `mistral:7b`)  
3. Install dependencies:  
    `pip install -r requirements.txt`  
4. Run server:  
    `python server.py`  
5. Open browser:  
    http://localhost:5000  

Troubleshooting ================> if you face any issues 
     Cannot connect → `ollama list` / `ollama serve`  
     No models → `ollama pull qwen2.5:3b`  
     Port in use → change port in `server.py` (e.g., 5001)  
     pip not recognized → `python -m pip install -r requirements.txt`  

