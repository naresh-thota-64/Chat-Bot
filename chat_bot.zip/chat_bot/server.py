from flask import Flask, request, jsonify, send_from_directory, Response
from flask_cors import CORS
import requests
import json

app = Flask(__name__, static_folder='.')
CORS(app)

# Ollama API endpoint (runs locally)
OLLAMA_API = "http://localhost:11434/api/chat"

@app.route('/')
def index():
    return send_from_directory('.', 'index.html')

@app.route('/<path:path>')
def serve_static(path):
    return send_from_directory('.', path)

@app.route('/api/chat', methods=['POST'])
def chat():
    try:
        data = request.json
        user_message = data.get('message', '')
        model = data.get('model', 'gemma:2b')  # Fast model!
        
        print(f"📩 Received: {user_message[:]}...")
        print(f"🤖 Using model: {model}")
        
        if not user_message:
            return jsonify({'error': 'No message provided'}), 400
        
        # Prepare Ollama request
        ollama_payload = {
            "model": "qwen2.5:3b",
            "messages": [
                {"role": "user", "content": user_message}
            ],
            "stream": False
        }
        
        print(f"🚀 Calling Ollama...")
        
        # Call Ollama API
        response = requests.post(OLLAMA_API, json=ollama_payload, timeout=120)
        
        if response.status_code == 200:
            result = response.json()
            bot_message = result.get('message', {}).get('content', 'No response generated.')
            print(f"✅ Got response: {bot_message[:100]}...")
            return jsonify({'response': bot_message})
        else:
            error_msg = f"Ollama error {response.status_code}: {response.text}"
            print(f"❌ {error_msg}")
            return jsonify({'error': error_msg}), response.status_code
        
    except requests.exceptions.ConnectionError:
        error_msg = 'Cannot connect to Ollama. Make sure Ollama is running (ollama serve).'
        print(f"❌ {error_msg}")
        return jsonify({'error': error_msg}), 503
    except requests.exceptions.Timeout:
        error_msg = 'Request timed out. Try a smaller model or shorter prompt.'
        print(f"⏱️ {error_msg}")
        return jsonify({'error': error_msg}), 408
    except Exception as e:
        error_msg = str(e)
        print(f"❌ Error: {error_msg}")
        return jsonify({'error': f'Error: {error_msg}'}), 500

@app.route('/api/models', methods=['GET'])
def get_models():
    """Get list of available Ollama models"""
    try:
        response = requests.get("http://localhost:11434/api/tags")
        if response.status_code == 200:
            models = response.json().get('models', [])
            model_names = [m['name'] for m in models]
            return jsonify({'models': model_names})
        else:
            return jsonify({'models': []}), 200
    except:
        return jsonify({'models': []}), 200

if __name__ == '__main__':
    print("🚀 kimi Chatbot Server Running!")
    print("📡 Open your browser and go to: http://localhost:5000")
    print("🔑 Your token: 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")
    print("\n⚡ Press Ctrl+C to stop the server\n")
    app.run(debug=True, port=5000)
