// Global variables
let currentChatId = Date.now();
let chatHistory = JSON.parse(localStorage.getItem('chat_history')) || [];
let currentMessages = [];
let availableModels = [];
let selectedModel = 'gemma:2b';  

// DOM elements
const tokenModal = document.getElementById('tokenModal');const settingsModal = document.getElementById('settingsModal');
const modelSelect = document.getElementById('modelSelect');
const closeSettingsBtn = document.getElementById('closeSettings');
const settingsBtn = document.getElementById('settingsBtn');
const clearHistoryBtn = document.getElementById('clearHistoryBtn');
const messageInput = document.getElementById('messageInput');
const sendBtn = document.getElementById('sendBtn');
const messagesContainer = document.getElementById('messagesContainer');
const welcomeScreen = document.getElementById('welcomeScreen');
const chatArea = document.getElementById('chatArea');
const newChatBtn = document.getElementById('newChatBtn');
const chatHistoryContainer = document.getElementById('chatHistory');
const changeTokenBtn = document.getElementById('changeTokenBtn');
const sidebarToggle = document.getElementById('sidebarToggle');
const sidebar = document.getElementById('sidebar');

// Hugging Face API configuration
const API_URL = 'https://api-inference.huggingface.co/models/mistralai/Mistral-7B-Instruct-v0.2';

// Initialize app
function init() {
    hideTokenModal();
    loadAvailableModels();
    loadChatHistory();
    setupEventListeners();
    adjustTextareaHeight();
}

// Load available Ollama models
async function loadAvailableModels() {
    try {
        const response = await fetch('/api/models');
        const data = await response.json();
        availableModels = data.models || [];
        
        if (availableModels.length > 0) {
            // Update dropdown
            modelSelect.innerHTML = availableModels.map(model => 
                `<option value="${model}" ${model === selectedModel ? 'selected' : ''}>${model}</option>`
            ).join('');
            
            // Set default model if current is not in list
            if (!availableModels.includes(selectedModel)) {
                selectedModel = availableModels[0];
            }
            
            console.log('Available models:', availableModels);
        } else {
            modelSelect.innerHTML = '<option value="">No models found. Run: ollama pull phi3</option>';
        }
    } catch (error) {
        console.log('Could not load models:', error);
        modelSelect.innerHTML = '<option value="">Error loading models</option>';
    }
}

// Show/hide token modal
function showTokenModal() {
    // No longer needed for Ollama
    tokenModal.classList.add('hidden');
}

function hideTokenModal() {
    tokenModal.classList.add('hidden');
}

// Setup event listeners
function setupEventListeners() {
    sendBtn.addEventListener('click', sendMessage);
    
    messageInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });
    
    messageInput.addEventListener('input', adjustTextareaHeight);
    
    newChatBtn.addEventListener('click', startNewChat);
    
    // Settings modal
    settingsBtn.addEventListener('click', () => {
        settingsModal.classList.remove('hidden');
    });
    
    closeSettingsBtn.addEventListener('click', () => {
        settingsModal.classList.add('hidden');
    });
    
    // Clear history button
    clearHistoryBtn.addEventListener('click', () => {
        if (confirm('Are you sure you want to delete all chat history? This cannot be undone.')) {
            chatHistory = [];
            localStorage.removeItem('chat_history');
            loadChatHistory();
            startNewChat();
            alert('Chat history cleared successfully!');
        }
    });
    
    // Model selection
    modelSelect.addEventListener('change', (e) => {
        selectedModel = e.target.value;
        localStorage.setItem('selected_model', selectedModel);
        console.log('Model changed to:', selectedModel);
    });
    
    // Load saved model preference
    const savedModel = localStorage.getItem('selected_model');
    if (savedModel) {
        selectedModel = savedModel;
    }
    
    // Quick action buttons
    document.querySelectorAll('.quick-action-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const prompt = btn.getAttribute('data-prompt');
            messageInput.value = prompt;
            sendMessage();
        });
    });
    
    // Sidebar toggle for mobile
    sidebarToggle.addEventListener('click', () => {
        sidebar.classList.toggle('active');
    });
    
    // Close modals on backdrop click
    settingsModal.addEventListener('click', (e) => {
        if (e.target === settingsModal) {
            settingsModal.classList.add('hidden');
        }
    });
}

// Adjust textarea height
function adjustTextareaHeight() {
    messageInput.style.height = 'auto';
    messageInput.style.height = Math.min(messageInput.scrollHeight, 200) + 'px';
}

// Start new chat
function startNewChat() {
    currentChatId = Date.now();
    currentMessages = [];
    messagesContainer.innerHTML = '';
    welcomeScreen.style.display = 'block';
    messageInput.value = '';
    messageInput.focus();
}

// Send message
async function sendMessage() {
    const message = messageInput.value.trim();
    if (!message) return;
    
    // Hide welcome screen
    welcomeScreen.style.display = 'none';
    
    // Clear input
    messageInput.value = '';
    adjustTextareaHeight();
    
    // Add user message
    addMessage('user', message);
    currentMessages.push({ role: 'user', content: message });
    
    // Show typing indicator
    const typingIndicator = showTypingIndicator();
    
    // Get AI response
    try {
        const response = await queryOllama(message);
        
        // Remove typing indicator
        typingIndicator.remove();
        
        // Add bot response
        addMessage('assistant', response);
        currentMessages.push({ role: 'assistant', content: response });
        
        // Save to chat history
        saveChatToHistory(message);
        
    } catch (error) {
        typingIndicator.remove();
        addMessage('assistant', `⚠️ ${error.message}`);
    }
}

// Query Ollama API via backend proxy
async function queryOllama(message) {
    try {
        const response = await fetch('/api/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                message: message,
                model: selectedModel
            })
        });
        
        const data = await response.json();
        
        if (!response.ok) {
            throw new Error(data.error || 'Failed to get response');
        }
        
        return data.response || 'No response generated.';
        
    } catch (error) {
        throw error;
    }
}

// Add message to chat
function addMessage(role, content, shouldScroll = true) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message';
    
    const isUser = role === 'user';
    const avatarClass = isUser ? 'user-avatar' : 'bot-avatar';
    const name = isUser ? 'You' : 'Kimi';
    const avatarText = isUser ? 'N' : '🤖';
    
    messageDiv.innerHTML = `
        <div class="message-header">
            <div class="message-avatar ${avatarClass}">${avatarText}</div>
            <div class="message-name">${name}</div>
        </div>
        <div class="message-content">${formatMessage(content)}</div>
    `;
    
    messagesContainer.appendChild(messageDiv);
    if (shouldScroll) {
        chatArea.scrollTop = chatArea.scrollHeight;
    }
}

// Format message content
function formatMessage(content) {
    // Replace code blocks
    content = content.replace(/```(\w+)?\n([\s\S]+?)```/g, '<pre><code>$2</code></pre>');
    
    // Replace inline code
    content = content.replace(/`([^`]+)`/g, '<code>$1</code>');
    
    // Replace line breaks
    content = content.replace(/\n/g, '<br>');
    
    return content;
}

// Show typing indicator
function showTypingIndicator() {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message';
    messageDiv.id = 'typing-indicator';
    
    messageDiv.innerHTML = `
        <div class="message-header">
            <div class="message-avatar bot-avatar">✦</div>
            <div class="message-name">Kimi</div>
        </div>
        <div class="typing-indicator">
            <div class="typing-dot"></div>
            <div class="typing-dot"></div>
            <div class="typing-dot"></div>
        </div>
    `;
    
    messagesContainer.appendChild(messageDiv);
    chatArea.scrollTop = chatArea.scrollHeight;
    
    return messageDiv;
}

// Save chat to history
function saveChatToHistory(firstMessage) {
    // Find existing chat
    const existingIndex = chatHistory.findIndex(chat => chat.id === currentChatId);
    
    if (existingIndex === -1) {
        // New chat - save with messages
        const newChat = {
            id: currentChatId,
            title: firstMessage.substring(0, 50) + (firstMessage.length > 50 ? '...' : ''),
            timestamp: Date.now(),
            messages: [...currentMessages]
        };
        chatHistory.unshift(newChat);
    } else {
        // Update existing chat
        chatHistory[existingIndex].messages = [...currentMessages];
        chatHistory[existingIndex].timestamp = Date.now();
    }
    
    // Keep only last 50 chats
    if (chatHistory.length > 50) {
        chatHistory = chatHistory.slice(0, 50);
    }
    
    localStorage.setItem('chat_history', JSON.stringify(chatHistory));
    loadChatHistory();
}

// Load chat history
function loadChatHistory() {
    chatHistoryContainer.innerHTML = '';
    
    if (chatHistory.length === 0) {
        chatHistoryContainer.innerHTML = '<div style="padding: 12px 16px; color: #9aa0a6; font-size: 14px;">No chat history yet</div>';
        return;
    }
    
    chatHistory.forEach(chat => {
        const chatItem = document.createElement('div');
        chatItem.className = 'chat-history-item';
        if (chat.id === currentChatId) {
            chatItem.classList.add('active');
        }
        chatItem.textContent = chat.title;
        chatItem.addEventListener('click', () => {
            loadChat(chat.id);
        });
        chatHistoryContainer.appendChild(chatItem);
    });
}

// Load a specific chat
function loadChat(chatId) {
    const chat = chatHistory.find(c => c.id === chatId);
    if (!chat) return;
    
    currentChatId = chat.id;
    currentMessages = [...chat.messages];
    
    // Clear and reload messages
    messagesContainer.innerHTML = '';
    welcomeScreen.style.display = 'none';
    
    chat.messages.forEach(msg => {
        addMessage(msg.role, msg.content, false);
    });
    
    loadChatHistory();
    chatArea.scrollTop = chatArea.scrollHeight;
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', init);
